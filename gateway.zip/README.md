# graphql-beaver-view
