export type SortOrder = '↑' | '↓' | '';
