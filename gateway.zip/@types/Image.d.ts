declare module '*.png' {
    const value: any;
    export default value;
}

declare module '*.jpg';
